#!/usr/bin/env python3
"""Gerador de compêndio YAML para Foundry VTT - CoC7 - Personagens Máscaras (Peru)"""
import yaml
import random
import string

# Gerador de ID de 16 caracteres alfanuméricos
def gen_id(prefix=""):
    chars = string.ascii_letters + string.digits
    remaining = 16 - len(prefix)
    return prefix + ''.join(random.choice(chars) for _ in range(remaining))

# Para reprodutibilidade
random.seed(42)

# IDs das pastas
FOLDER_ALIADOS = gen_id("fldA")
FOLDER_ADVERSARIOS = gen_id("fldB")

def make_skill(name, value, specialization="", properties=None, description=None, icon=None):
    """Cria um item de perícia (skill) no formato CoC7."""
    if properties is None:
        properties = {"push": True}
    skill = {
        "_id": gen_id("skl"),
        "name": name,
        "type": "skill",
        "img": icon or "systems/CoC7/assets/icons/skills.svg",
        "system": {
            "description": {"value": description or ""},
            "base": 0,
            "adjustments": {"personal": value},
            "skillName": name if not specialization else specialization,
            "specialization": specialization,
            "properties": properties
        }
    }
    return skill

def make_weapon(name, damage, skill_id, ranged=False, malfunction="", uses_per_round=None):
    """Cria uma arma (weapon) referenciando uma skill por _id."""
    props = {"rngd": ranged}
    if not ranged:
        props["addb"] = True
    w = {
        "_id": gen_id("wpn"),
        "name": name,
        "type": "weapon",
        "img": "icons/svg/sword.svg" if not ranged else "icons/svg/explosion.svg",
        "system": {
            "skill": {"main": {"id": skill_id}},
            "range": {"normal": {"damage": damage}},
            "usesPerRound": {"max": uses_per_round or "", "burst": "", "bullets": "", "malfunction": malfunction},
            "properties": props
        }
    }
    return w

def make_item(name, description=""):
    """Cria um item genérico (posse)."""
    return {
        "_id": gen_id("itm"),
        "name": name,
        "type": "item",
        "img": "icons/svg/item-bag.svg",
        "system": {"description": {"value": description}, "quantity": 1, "weight": 0, "price": 0}
    }

def make_talent(name, description="", talent_type="physical"):
    """Cria um talento pulp."""
    return {
        "_id": gen_id("tlt"),
        "name": name,
        "type": "talent",
        "img": "icons/svg/upgrade.svg",
        "system": {
            "source": "",
            "description": {"value": description},
            "type": {talent_type: True}
        }
    }

def make_actor(name, actor_type, characteristics, attribs, infos, items, folder,
               san_loss=None, attacks_per_round=1, biography="", flags_extra=None,
               prototype_token=None, locked=True):
    """Cria um ator (character/npc/creature) completo."""
    actor = {
        "_id": gen_id("act"),
        "name": name,
        "type": actor_type,
        "img": prototype_token.get("texture", {}).get("src") if prototype_token else "icons/svg/mystery-man.svg",
        "folder": folder,
        "system": {
            "characteristics": characteristics,
            "attribs": attribs,
            "infos": infos,
            "flags": {"locked": locked, "displayFormula": False}
        },
        "items": items
    }
    if san_loss:
        actor["system"]["attribs"]["special"] = {
            "sanLoss": {
                "checkPassed": san_loss[0],
                "checkFailled": san_loss[1]
            }
        }
    actor["system"]["attribs"]["special"] = actor["system"]["attribs"].get("special", {})
    actor["system"]["attribs"]["special"]["attacksPerRound"] = attacks_per_round
    if biography:
        actor["system"]["biography"] = {"personalDescription": {"value": biography}}
    if prototype_token:
        actor["prototypeToken"] = prototype_token
    if flags_extra:
        actor["flags"] = flags_extra
    return actor

# ============ PERSONAGENS ============

documents = []

# --- Pastas (Folders) ---
documents.append({
    "_id": FOLDER_ALIADOS,
    "name": "Aliados ou Independentes",
    "type": "folder",
    "folder": None,
    "sort": 0,
    "sorting": "a",
    "color": None,
    "flags": {}
})
documents.append({
    "_id": FOLDER_ADVERSARIOS,
    "name": "Adversários e Monstros",
    "type": "folder",
    "folder": None,
    "sort": 1,
    "sorting": "a",
    "color": None,
    "flags": {}
})

# ============ 1. Professor Nemesio Sánchez (NPC) ============
ns_items = []
ns_briga = make_skill("Briga", 30, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
ns_items.append(ns_briga)
ns_items.append(make_weapon("Punhos", "1D3", ns_briga["_id"]))
ns_items.append(make_skill("Esquiva", 32, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Antropologia", 40), ("Arqueologia", 80), ("Arremessar", 40),
                    ("Encontrar", 60), ("História", 65), ("Lábia", 70),
                    ("Nível de Crédito", 40), ("Persuasão", 40), ("Usar Bibliotecas", 65)]:
    ns_items.append(make_skill(sname, sval))
ns_items.append(make_skill("Língua (Inglês)", 40, "Inglês", "Language"))
ns_items.append(make_skill("Língua (Espanhol)", 80, "Espanhol", "Language"))
ns_items.append(make_talent("Visão Aguçada", "Concede um dado de bônus a testes de Encontrar.", "mental"))

ns_actor = make_actor(
    "Professor Nemesio Sánchez", "npc",
    {"str": {"value": 50}, "con": {"value": 55}, "siz": {"value": 60}, "dex": {"value": 65},
     "app": {"value": 65}, "int": {"value": 75}, "pow": {"value": 50}, "edu": {"value": 85}},
    {"hp": {"value": 11, "max": 11}, "mp": {"value": 10, "max": 10}, "lck": {"value": 0},
     "san": {"value": 50, "max": 99}, "mov": {"value": 8}, "armor": {"value": 0}, "auto": False},
    {"occupation": "Arqueólogo acadêmico", "age": "35"},
    ns_items, FOLDER_ALIADOS,
    biography="<p>Arqueólogo acadêmico de 35 anos. Especialista em culturas andinas. Embora tenha algum conhecimento do Mythos de Cthulhu, ele não acredita que seja real antes dos eventos deste cenário. Até ser apresentado a provas incontestáveis, ele afirma que coisas relacionadas ao Mythos não passam de folclore ou invenciones.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(ns_actor)

# ============ 2. Jackson Elias (NPC) ============
je_items = []
je_briga = make_skill("Briga", 60, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
je_items.append(je_briga)
je_items.append(make_weapon("Punhos", "1D3+1D4", je_briga["_id"]))
je_revolver = make_skill("Arma de Fogo (Revólver .45)", 60, "Revólver .45", "Firearms", {"firearm": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/firearms_handgun.svg")
je_items.append(je_revolver)
je_items.append(make_weapon("Revólver .45", "1D10+2", je_revolver["_id"], ranged=True, malfunction="100"))
je_items.append(make_skill("Esquiva", 50, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Arremessar", 35), ("Arte/Ofício (Escrita)", 70), ("Charme", 45),
                    ("Consertos Mecânicos", 50), ("Dirigir Automóveis", 50), ("Encontrar", 60),
                    ("Escalar", 60), ("Escutar", 55), ("Furtividade", 65), ("Lábia", 70),
                    ("Mundo Natural", 45), ("Mythos de Cthulhu", 4), ("Nível de Crédito", 40),
                    ("Ocultismo", 70), ("Persuasão", 40), ("Psicologia", 50),
                    ("Sobrevivência (Montanhas)", 25), ("Usar Bibliotecas", 65)]:
    props = {"push": True}
    if sname == "Mythos de Cthulhu":
        props = {"noxpgain": True}
    if sname == "Nível de Crédito":
        props = {"noxpgain": True, "push": True}
    je_items.append(make_skill(sname, sval, properties=props))
for lang, val in [("Chinês (Cantonês)", 20), ("Inglês", 85), ("Francês", 40),
                  ("Hindustani", 40), ("Português", 45), ("Espanhol", 50)]:
    je_items.append(make_skill(f"Língua ({lang})", val, lang, "Language"))
je_items.append(make_talent("Alerta", "Nunca é surpreendido em combate.", "mental"))
je_items.append(make_talent("Casca-grossa", "Absorve dano; pode gastar 10 pontos de Sorte para ignorar até 5 de dano recebidos em uma rodada de combate.", "physical"))

je_actor = make_actor(
    "Jackson Elias", "npc",
    {"str": {"value": 70}, "con": {"value": 85}, "siz": {"value": 65}, "dex": {"value": 65},
     "app": {"value": 55}, "int": {"value": 80}, "pow": {"value": 80}, "edu": {"value": 70}},
    {"hp": {"value": 15, "max": 15}, "mp": {"value": 16, "max": 16}, "lck": {"value": 80},
     "san": {"value": 76, "max": 99}, "mov": {"value": 6}, "armor": {"value": 1}, "auto": False,
     "db": {"value": "+1D4"}},
    {"occupation": "Investigador destemido", "age": "41"},
    je_items, FOLDER_ALIADOS,
    biography="<p>Investigador destemido de 41 anos. Autor de diversos livros sobre cultos e o oculto. Está no Peru investigando a Irmandade da Serpente e a pirâmide da Serpente de Yig.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(je_actor)

# ============ 3. Trinidad Rizo (NPC) ============
tr_items = []
tr_briga = make_skill("Briga", 25, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
tr_items.append(tr_briga)
tr_items.append(make_weapon("Punhos", "1D3", tr_briga["_id"]))
tr_items.append(make_skill("Esquiva", 32, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Antropologia", 20), ("Arqueologia", 50), ("Arremessar", 30),
                    ("Encontrar", 60), ("Escutar", 40), ("Furtividade", 35),
                    ("História", 45), ("Nível de Crédito", 20), ("Usar Bibliotecas", 65)]:
    props = {"push": True}
    if sname == "Nível de Crédito":
        props = {"noxpgain": True, "push": True}
    tr_items.append(make_skill(sname, sval, properties=props))
tr_items.append(make_skill("Língua (Inglês)", 10, "Inglês", "Language"))
tr_items.append(make_skill("Língua (Espanhol)", 70, "Espanhol", "Language"))

tr_actor = make_actor(
    "Trinidad Rizo", "npc",
    {"str": {"value": 55}, "con": {"value": 65}, "siz": {"value": 50}, "dex": {"value": 65},
     "app": {"value": 55}, "int": {"value": 70}, "pow": {"value": 50}, "edu": {"value": 65}},
    {"hp": {"value": 11, "max": 11}, "mp": {"value": 10, "max": 10}, "lck": {"value": 0},
     "san": {"value": 50, "max": 99}, "mov": {"value": 9}, "armor": {"value": 0}, "auto": False},
    {"occupation": "Estudante empolgada", "age": "19"},
    tr_items, FOLDER_ALIADOS,
    biography="<p>Estudante de arqueologia de 19 anos, empolgada e ansiosa para participar da expedição. Estudante do Professor Nemesio Sánchez.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(tr_actor)

# ============ 4. Petronila Cupitina (NPC) ============
pc_items = []
pc_briga = make_skill("Briga", 25, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
pc_items.append(pc_briga)
pc_items.append(make_weapon("Punhos", "1D3-1", pc_briga["_id"]))
pc_bengala = make_skill("Briga (Bengala)", 25, "Bengala", "Fighting", {"fighting": True, "combat": True, "special": True})
pc_items.append(pc_bengala)
pc_items.append(make_weapon("Bengala", "1D6-1", pc_bengala["_id"]))
pc_items.append(make_skill("Esquiva", 17, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Arremessar", 30), ("Balançar Bengala Ameaçadoramente", 55),
                    ("Encontrar", 50), ("Escutar", 55), ("Intimidação", 55),
                    ("Nível de Crédito", 50), ("Psicologia", 40)]:
    props = {"push": True}
    if sname == "Nível de Crédito":
        props = {"noxpgain": True, "push": True}
    pc_items.append(make_skill(sname, sval, properties=props))
pc_items.append(make_skill("Língua (Espanhol)", 65, "Espanhol", "Language"))

pc_actor = make_actor(
    "Petronila Cupitina", "npc",
    {"str": {"value": 30}, "con": {"value": 55}, "siz": {"value": 45}, "dex": {"value": 35},
     "app": {"value": 45}, "int": {"value": 65}, "pow": {"value": 70}, "edu": {"value": 50}},
    {"hp": {"value": 10, "max": 10}, "mp": {"value": 14, "max": 14}, "lck": {"value": 0},
     "san": {"value": 70, "max": 99}, "mov": {"value": 3}, "armor": {"value": -1}, "auto": False,
     "db": {"value": "-1"}},
    {"occupation": "Hoteleira pragmática", "age": "71"},
    pc_items, FOLDER_ALIADOS,
    biography="<p>Hoteleira pragmática de 71 anos. Dona do hotel onde os investigadores se hospedam. Conhece todos os fofocas da cidade e não se deixa abalar por nada.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(pc_actor)

# ============ 5. Nayra (NPC) ============
ny_items = []
ny_briga = make_skill("Briga", 25, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
ny_items.append(ny_briga)
ny_items.append(make_weapon("Punhos", "1D3", ny_briga["_id"]))
ny_items.append(make_skill("Esquiva", 25, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Clarividência e Divinação", 55), ("Conhecimento (Folclore Peruano)", 70),
                    ("Encontrar", 50), ("Escutar", 40), ("História", 50), ("Medicina", 50),
                    ("Mythos de Cthulhu", 2), ("Ocultismo", 65), ("Persuasão", 55),
                    ("Primeiros Socorros", 70), ("Psicologia", 60)]:
    props = {"push": True}
    if sname == "Mythos de Cthulhu":
        props = {"noxpgain": True}
    ny_items.append(make_skill(sname, sval, properties=props))
ny_items.append(make_skill("Língua (Aymara)", 65, "Aymara", "Language"))
ny_items.append(make_skill("Língua (Espanhol)", 40, "Espanhol", "Language"))
ny_items.append(make_talent("Poder Psíquico: Divinação", "Divinação 60%.", "mental"))
ny_items.append(make_talent("Poder Psíquico: Clarividência", "Clarividência 50%.", "mental"))

ny_actor = make_actor(
    "Nayra", "npc",
    {"str": {"value": 40}, "con": {"value": 55}, "siz": {"value": 50}, "dex": {"value": 50},
     "app": {"value": 50}, "int": {"value": 65}, "pow": {"value": 80}, "edu": {"value": 65}},
    {"hp": {"value": 10, "max": 10}, "mp": {"value": 16, "max": 16}, "lck": {"value": 0},
     "san": {"value": 80, "max": 99}, "mov": {"value": 3}, "armor": {"value": 0}, "auto": False},
    {"occupation": "Curandeira e sábia", "age": "76"},
    ny_items, FOLDER_ALIADOS,
    biography="<p>Curandeira e sábia de 76 anos. Conhece as tradições andinas e os segredos da região. Possui poderes psíquicos de clarividência e divinação. As perícias psíquicas de Nayra se aplicam tanto em jogos clássicos quanto em jogos pulp.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(ny_actor)

# ============ 6. Julio Céspedes (NPC) ============
jc_items = []
jc_briga = make_skill("Briga", 40, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
jc_items.append(jc_briga)
jc_items.append(make_weapon("Punhos", "1D3+1D4", jc_briga["_id"]))
jc_rifle = make_skill("Arma de Fogo (Rifle)", 40, "Rifle", "Firearms", {"firearm": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/firearms_rifle_shotgun.svg")
jc_items.append(jc_rifle)
jc_items.append(make_weapon("Rifle", "2D6+4", jc_rifle["_id"], ranged=True))
jc_items.append(make_skill("Esquiva", 30, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Escutar", 35), ("Encontrar", 40), ("Psicologia", 45)]:
    jc_items.append(make_skill(sname, sval))
jc_items.append(make_skill("Língua (Espanhol)", 45, "Espanhol", "Language"))

jc_actor = make_actor(
    "Julio Céspedes", "npc",
    {"str": {"value": 65}, "con": {"value": 65}, "siz": {"value": 65}, "dex": {"value": 55},
     "app": {"value": 40}, "int": {"value": 50}, "pow": {"value": 45}, "edu": {"value": 45}},
    {"hp": {"value": 13, "max": 13}, "mp": {"value": 9, "max": 9}, "lck": {"value": 0},
     "san": {"value": 45, "max": 99}, "mov": {"value": 8}, "armor": {"value": 1}, "auto": False,
     "db": {"value": "+1D4"}},
    {"occupation": "Pai protetor", "age": "38"},
    jc_items, FOLDER_ALIADOS,
    biography="<p>Pai protetor de 38 anos. Seu filho Domingo foi gravemente ferido. Está disposto a tudo para protegê-lo e encontrar os responsáveis.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(jc_actor)

# ============ 7. Domingo Céspedes (NPC) ============
dc_items = []
dc_briga = make_skill("Briga", 40, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
dc_items.append(dc_briga)
dc_items.append(make_weapon("Punhos", "1D3", dc_briga["_id"]))
dc_items.append(make_skill("Esquiva", 10, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Escutar", 35), ("Encontrar", 40), ("Psicologia", 30)]:
    dc_items.append(make_skill(sname, sval))
dc_items.append(make_skill("Língua (Espanhol)", 55, "Espanhol", "Language"))

dc_actor = make_actor(
    "Domingo Céspedes", "npc",
    {"str": {"value": 60}, "con": {"value": 55}, "siz": {"value": 55}, "dex": {"value": 65},
     "app": {"value": 60}, "int": {"value": 60}, "pow": {"value": 55}, "edu": {"value": 50}},
    {"hp": {"value": 3, "max": 11}, "mp": {"value": 11, "max": 11}, "lck": {"value": 0},
     "san": {"value": 55, "max": 99}, "mov": {"value": 0, "max": 9}, "armor": {"value": 0}, "auto": False},
    {"occupation": "Filho gravemente ferido", "age": "15"},
    dc_items, FOLDER_ALIADOS,
    biography="<p>Filho de Julio Céspedes, 15 anos. Foi gravemente ferido por um kharisiri. Atualmente os pontos de vida e movimento estão reduzidos devido ao ferimento. PVs atuais: 3 (máximo 11). Movimento atual: 0 (máximo 9). Esquiva normalmente 27%, atualmente 10%.</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": 1}
)
documents.append(dc_actor)

# ============ 8. Augustus Larkin (forma humana) (NPC) ============
al_items = []
al_briga = make_skill("Briga", 25, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
al_items.append(al_briga)
al_items.append(make_weapon("Punhos", "1D3", al_briga["_id"]))
al_items.append(make_skill("Esquiva", 22, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Arremessar", 30), ("Charme", 45), ("Encontrar", 40),
                    ("Escutar", 55), ("Furtividade", 50), ("Intimidação", 25),
                    ("Lábia", 70), ("Mythos de Cthulhu", 27), ("Nível de Crédito", 60),
                    ("Persuasão", 40), ("Psicologia", 40), ("Usar Bibliotecas", 25)]:
    props = {"push": True}
    if sname == "Mythos de Cthulhu":
        props = {"noxpgain": True}
    if sname == "Nível de Crédito":
        props = {"noxpgain": True, "push": True}
    al_items.append(make_skill(sname, sval, properties=props))
for lang, val in [("Inglês", 65), ("Kikuyu", 15), ("Espanhol", 30), ("Swahili", 25)]:
    al_items.append(make_skill(f"Língua ({lang})", val, lang, "Language"))
al_items.append(make_talent("Poder Psíquico: Divinação", "Divinação 60%.", "mental"))

al_actor = make_actor(
    "Augustus Larkin (humano)", "npc",
    {"str": {"value": 45}, "con": {"value": 35}, "siz": {"value": 65}, "dex": {"value": 45},
     "app": {"value": 45}, "int": {"value": 60}, "pow": {"value": 50}, "edu": {"value": 65}},
    {"hp": {"value": 10, "max": 10}, "mp": {"value": 10, "max": 10}, "lck": {"value": 50},
     "san": {"value": 9, "max": 99}, "mov": {"value": 7}, "armor": {"value": 0}, "auto": False},
    {"occupation": "Hospedeiro de Nyarlathotep (forma humana)", "age": "32"},
    al_items, FOLDER_ADVERSARIOS,
    biography="<p>Augustus Larkin, 32 anos. Este perfil é para Larkin em forma humana. Se ele ficar completamente possuído, veja Augustus Larkin Possuído por Nyarlathotep. Larkin ainda possui um resquício de humanidade (SAN 09).</p>",
    prototype_token={"texture": {"src": "icons/svg/mystery-man.svg"}, "disposition": -1}
)
documents.append(al_actor)

# ============ 9. Augustus Larkin Possuído por Nyarlathotep (criatura) ============
lp_items = []
lp_briga = make_skill("Briga", 90, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
lp_items.append(lp_briga)
lp_items.append(make_weapon("Punhos", "1D4+1D3", lp_briga["_id"]))
lp_items.append(make_skill("Esquiva", 60, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Arremessar", 80), ("Encontrar", 99), ("Escutar", 99),
                    ("Intimidação", 99), ("Psicologia", 90)]:
    lp_items.append(make_skill(sname, sval, properties={"push": False}))
lp_items.append(make_talent("Alerta", "Nunca é surpreendido em combate.", "mental"))

lp_actor = make_actor(
    "Augustus Larkin Possuído por Nyarlathotep", "creature",
    {"str": {"value": 60}, "con": {"value": 95}, "siz": {"value": 65}, "dex": {"value": 95},
     "app": {"value": 45}, "int": {"value": 430}, "pow": {"value": 500}, "edu": {"value": 0}},
    {"hp": {"value": 16, "max": 16}, "mp": {"value": 100, "max": 100}, "lck": {"value": 0},
     "san": {"value": 0, "max": 0}, "mov": {"value": 7}, "armor": {"value": 1}, "auto": False,
     "db": {"value": "+1D4"}},
    {"occupation": "Arauto das trevas", "age": "—"},
    lp_items, FOLDER_ADVERSARIOS,
    san_loss=("0", "0"),
    biography="<p>Arauto das trevas, forma possuída de Augustus Larkin por Nyarlathotep. Armadura: nenhuma; Larkin pode ser morto por meios físicos normais. Ao contrário de outros hospedeiros possuídos por Nyarlathotep, Larkin não se assume uma forma monstruosa ao morrer. Feitiços: Nyarlathotep conhece todos os feitiços do Mythos, usa Sugestão Mental quando necessário. Perda de Sanidade: nenhuma.</p>",
    prototype_token={"texture": {"src": "systems/CoC7/assets/icons/floating-tentacles.svg"}, "disposition": -2}
)
documents.append(lp_actor)

# ============ 10. Luis de Mendoza (kharisiri) (criatura) ============
lm_items = []
lm_lutar = make_skill("Lutar", 75, "Lutar", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
lm_items.append(lm_lutar)
lm_items.append(make_weapon("Garras/Socar", "1D3+1D6", lm_lutar["_id"]))
lm_agarrar = make_skill("Agarrar (mnbr)", 75, "Agarrar", "Fighting", {"fighting": True, "combat": True, "special": True})
lm_items.append(lm_agarrar)
lm_espada = make_skill("Lutar (Espada)", 50, "Espada", "Fighting", {"fighting": True, "combat": True, "special": True})
lm_items.append(lm_espada)
lm_items.append(make_weapon("Espada de conquistador", "1D8+1D6", lm_espada["_id"]))
lm_items.append(make_skill("Esquiva", 60, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
for sname, sval in [("Encontrar", 60), ("Escutar", 60), ("Furtividade", 70), ("Intimidação", 70)]:
    lm_items.append(make_skill(sname, sval, properties={"push": False}))
lm_items.append(make_talent("Ataques Rápidos", "Pode gastar 10 pontos de Sorte para ganhar outro ataque corpo a corpo em uma única rodada de combate.", "physical"))

lm_actor = make_actor(
    "Luis de Mendoza (kharisiri)", "creature",
    {"str": {"value": 100}, "con": {"value": 90}, "siz": {"value": 65}, "dex": {"value": 75},
     "app": {"value": 50}, "int": {"value": 30}, "pow": {"value": 50}, "edu": {"value": 20}},
    {"hp": {"value": 15, "max": 15}, "mp": {"value": 10, "max": 10}, "lck": {"value": 25},
     "san": {"value": 0, "max": 0}, "mov": {"value": 7}, "armor": {"value": 2}, "auto": False,
     "db": {"value": "+1D6"}},
    {"occupation": "Conquistador morto-vivo", "age": "—"},
    lm_items, FOLDER_ADVERSARIOS,
    san_loss=("0", "1D6"),
    biography="<p>Conquistador espanhol morto-vivo, um kharisiri (sanguessuga imortal). Agarrar (mnbr): segura e prende uma vítima, pronto para sugar a vida dela. Na rodada seguinte, sua boca se prende ao corpo da vítima e começa a sugar gordura, sangue e outros fluidos, devorando 1D10 de FOR, 1D10 de CON, e 1D4 de TAM por rodada até se saciar ou parar (com zero de CON a vítima morre). A vítima pode tentar libertar-se com um teste resistido de FOR. Se sobreviver, recupera FOR e CON à taxa de 1D10 pontos por semana, e 1 de TAM por semana, mas fica com cicatriz hedionda. Armadura: regenera 1 PV por rodada após atingir 0. Só pode ser morto por desmembramento completo ou incineração. Se apenas decapitado, pode se recuperar se encontrar a cabeça e recolocá-la. Se a conexão com o Pai dos Vermes for cortada pela restauração do sigilo, perde a regeneração e desfaz-se à taxa de 1 PV a cada 10 minutos. Regenera 2 PVs por rodada. Feitiços: Contactar Pai dos Vermes (Nyarlathotep). Perda de Sanidade: 0/1D6 por ver na forma monstruosa ou em transformação; nenhuma em forma humana.</p>",
    prototype_token={"texture": {"src": "systems/CoC7/assets/icons/cultist.svg"}, "disposition": -2}
)
documents.append(lm_actor)

# ============ 11. Kharisiri (genérico) (criatura) ============
kh_items = []
kh_briga = make_skill("Briga", 60, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
kh_items.append(kh_briga)
kh_items.append(make_weapon("Garras/Socar", "1D3+1D4", kh_briga["_id"]))
kh_agarrar = make_skill("Agarrar (mnbr)", 60, "Agarrar", "Fighting", {"fighting": True, "combat": True, "special": True})
kh_items.append(kh_agarrar)

kh_actor = make_actor(
    "Kharisiri (sanguessuga imortal)", "creature",
    {"str": {"value": 95}, "con": {"value": 90}, "siz": {"value": 65}, "dex": {"value": 65},
     "app": {"value": 50}, "int": {"value": 40}, "pow": {"value": 50}, "edu": {"value": 10}},
    {"hp": {"value": 15, "max": 15}, "mp": {"value": 10, "max": 10}, "lck": {"value": 0},
     "san": {"value": 0, "max": 0}, "mov": {"value": 7}, "armor": {"value": 1}, "auto": False,
     "db": {"value": "+1D4"}},
    {"occupation": "Sanguessuga imortal", "age": "—"},
    kh_items, FOLDER_ADVERSARIOS,
    san_loss=("0", "1D6"),
    biography="<p>Kharisiri — sanguessugas imortais, humanos transformados pelas larvas do Pai dos Vermes. Variações de estatísticas (1 a 4): FOR 90-100, CON 85-95, TAM 60-75, DES 55-75, POD 45-55, PVs 14-16, DX +1D4/+1D6, Corpo 1-2. Agarrar (mnbr): segura e prende uma vítima para sugar sua vida — devora 1D10 de FOR, 1D10 de CON e 1D4 de TAM por rodada. Vítima pode libertar-se com teste resistido de FOR. Kharisiri não se esquivam. Armadura: regenera 1 PV por rodada após atingir 0. Só pode ser morto por desmembramento completo ou incineração. Se a conexão com o Pai dos Vermes for cortada pela restauração do selo, perdem a regeneração e desfazem-se. Feitiços: Contactar Pai dos Vermes (Nyarlathotep). Perda de Sanidade: 0/1D6 na forma monstruosa; nenhuma em forma humana.</p>",
    prototype_token={"texture": {"src": "systems/CoC7/assets/icons/cultist.svg"}, "disposition": -2}
)
documents.append(kh_actor)

# ============ 12. Múmia Animada (criatura) ============
ma_items = []
ma_briga = make_skill("Briga", 30, "Brawl", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
ma_items.append(ma_briga)
ma_items.append(make_weapon("Soco/Rasgar", "1D3", ma_briga["_id"]))
ma_items.append(make_skill("Furtividade", 40))
ma_items.append(make_skill("Parecer uma Pilha de Trapos", 90, properties={"push": False}))

ma_actor = make_actor(
    "Múmia Animada", "creature",
    {"str": {"value": 80}, "con": {"value": 80}, "siz": {"value": 40}, "dex": {"value": 35},
     "app": {"value": 0}, "int": {"value": 0}, "pow": {"value": 5}, "edu": {"value": 0}},
    {"hp": {"value": 12, "max": 12}, "mp": {"value": 1, "max": 1}, "lck": {"value": 0},
     "san": {"value": 0, "max": 0}, "mov": {"value": 6}, "armor": {"value": 0}, "auto": False},
    {"occupation": "Suposto monte de trapos", "age": "—"},
    ma_items, FOLDER_ADVERSARIOS,
    san_loss=("0", "1D8"),
    biography="<p>Essas formas ressequidas são os restos das vítimas dos kharisiri, animadas por uma das larvas do deus. Ao contrário do kharisiri, são irracionais. Entrar em corpo (mnbr): uma larva pode entrar no corpo de um alvo através de qualquer orifício ou ferimento, desde que passe pelo menos uma rodada rastejando até o lugar. A gosma que exsuda da larva causa 1 ponto de dano por rodada se entrar em contato com pele nua. Múmias não se esquivam. Armadura: lesões graves causadas contra o tronco causam a perda de um membro; caso contrário, ignorar todo dano exceto na cabeça (um dado de penalidade para atingir a cabeça). Feitiços: nenhum. Perda de Sanidade: 0/1D8 pontos de Sanidade por encontrar uma múmia animada.</p>",
    prototype_token={"texture": {"src": "systems/CoC7/assets/icons/floating-tentacles.svg"}, "disposition": -2}
)
documents.append(ma_actor)

# ============ 13. Larva de Kharisiri (criatura) ============
lk_items = []
lk_lutar = make_skill("Lutar", 25, "Lutar", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
lk_items.append(lk_lutar)
lk_items.append(make_weapon("Toque cáustico", "1D3-2", lk_lutar["_id"]))
lk_entrar = make_skill("Entrar em corpo (mnbr)", 25, "Entrar em corpo", "Fighting", {"combat": True, "special": True})
lk_items.append(lk_entrar)
lk_items.append(make_skill("Esquiva", 75, "", "", {}, "systems/CoC7/assets/icons/skills/dodge.svg"))
lk_items.append(make_skill("Apertar-se em Passagens Pequenas", 90, properties={"push": False}))
lk_items.append(make_skill("Escalar", 70))
lk_items.append(make_skill("Furtividade", 60))

lk_actor = make_actor(
    "Larva de Kharisiri", "creature",
    {"str": {"value": 10}, "con": {"value": 45}, "siz": {"value": 5}, "dex": {"value": 85},
     "app": {"value": 0}, "int": {"value": 10}, "pow": {"value": 50}, "edu": {"value": 0}},
    {"hp": {"value": 5, "max": 5}, "mp": {"value": 10, "max": 10}, "lck": {"value": 0},
     "san": {"value": 0, "max": 0}, "mov": {"value": 9}, "armor": {"value": -2}, "auto": False,
     "db": {"value": "-2"}},
    {"occupation": "Semente de um deus", "age": "—"},
    lk_items, FOLDER_ADVERSARIOS,
    san_loss=("0", "1D3"),
    biography="<p>Embora pareçam entidades vivas, cada uma é na verdade um fragmento da carne do Pai dos Vermes. Tamanho aproximado de um punho humano, massa amorfa de protoplasma branco semelhante a gordura coagulada e rançosa. Cheira a carne podre, é escorregadia e pegajosa. Fluidos cáusticos causam queimaduras (1 ponto de dano por rodada de exposição). Deixam resíduo gorduroso. Fora de um hospedeiro, imediatamente tentam encontrar um novo. Ágeis, deslizam por superfícies e escalam paredes. Entram pela boca ou outros orifícios/ferimentos. Uma vez dentro, secreções param de causar dor mas vítima sente dor intolerável. Hospedeiro recém-infectado precisa de teste Extremo de CON para permanecer consciente. A menos que removida, o hospedeiro se torna um kharisiri. Entrar em corpo (mnbr): não é manobra de combate normal, não sujeita a penalidades por pouco Corpo. Armadura: nenhuma. Feitiços: nenhum. Perda de Sanidade: 0/1D3.</p>",
    prototype_token={"texture": {"src": "systems/CoC7/assets/icons/floating-tentacles.svg"}, "disposition": -2}
)
documents.append(lk_actor)

# ============ 14. Pai dos Vermes (criatura) ============
pv_items = []
pv_lutar = make_skill("Lutar (pseudópodes)", 85, "Pseudópodes", "Fighting", {"fighting": True, "combat": True, "special": True}, "systems/CoC7/assets/icons/skills/fighting_brawl.svg")
pv_items.append(pv_lutar)
pv_items.append(make_weapon("Pseudópodes", "7D6", pv_lutar["_id"]))
pv_pustulas = make_skill("Pústulas explosivas", 100, "Pústulas explosivas", "", {"combat": True, "special": True})
pv_items.append(pv_pustulas)
pv_items.append(make_weapon("Pústulas explosivas", "2D10", pv_pustulas["_id"], ranged=True))
pv_items.append(make_skill("Emite Odores Nefastos", 100, properties={"push": False}))

pv_actor = make_actor(
    "Pai dos Vermes", "creature",
    {"str": {"value": 200}, "con": {"value": 150}, "siz": {"value": 450}, "dex": {"value": 65},
     "app": {"value": 0}, "int": {"value": 1}, "pow": {"value": 500}, "edu": {"value": 0}},
    {"hp": {"value": 60, "max": 60}, "mp": {"value": 100, "max": 100}, "lck": {"value": 0},
     "san": {"value": 0, "max": 0}, "mov": {"value": 0}, "armor": {"value": 8}, "auto": False,
     "db": {"value": "+7D6"}},
    {"occupation": "Avatar aprisionado de Nyarlathotep", "age": "—"},
    pv_items, FOLDER_ADVERSARIOS,
    san_loss=("1D6", "1D20"),
    biography="<p>Massa monstruosa e convoluta feita inteiramente de gordura rançosa com vida não natural. Superfície iridescente se contorce com larvas e vermes. Cria pseudópodes instáveis que gotejam fluido branco, ou emana jatos de fluidos de pústulas explosivas. Avatar menor de Nyarlathotep — em grande parte imóvel e sem inteligência sobre-humana. Enquanto os selos da pirâmide permanecerem intactos, está contido. Ataques corpo a corpo: pseudópodes alcançam até 6 metros. Pústulas explosivas: quem estiver dentro de 100 metros sofre 2D10 de dano por queimaduras; cobertura leve não protege, cobertura pesada pode negar ou reduzir à metade. Especial: fedor de decomposição tão avassalador que investigadores em sua presença precisam passar em teste de CON ou são incapacitados por náuseas e vômitos. O Pai dos Vermes não se esquiva. Armadura: nenhuma. Feitiços: nenhum; este avatar idiótico não conta com poder mágico. Perda de Sanidade: 1D6/1D20 pontos de Sanidade.</p>",
    prototype_token={"texture": {"src": "systems/CoC7/assets/icons/floating-tentacles.svg"}, "disposition": -2}
)
documents.append(pv_actor)

# ============ Escrever YAML ============
output_path = "/home/user/.super_doubao/super-doubao-runtime/workspace/personagens-mascaras/src/packs/peru-personagens.yaml"

class IndentDumper(yaml.Dumper):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)

with open(output_path, "w", encoding="utf-8") as f:
    for i, doc in enumerate(documents):
        if i > 0:
            f.write("---\n")
        yaml.dump(doc, f, Dumper=IndentDumper, allow_unicode=True, default_flow_style=False, sort_keys=False, width=4096)

print(f"Gerado {len(documents)} documentos em {output_path}")
print(f"Pastas: Aliados={FOLDER_ALIADOS}, Adversarios={FOLDER_ADVERSARIOS}")
