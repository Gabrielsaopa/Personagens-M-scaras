# Personagens - Máscaras de Nyarlathotep (Peru)

Módulo para Foundry VTT com compêndio de personagens do cenário **Máscaras de Nyarlathotep** (Call of Cthulhu 7ª Edição), capítulo **Peru**.

## Conteúdo

### Pasta: Aliados ou Independentes (8 NPCs)
1. Professor Nemesio Sánchez — arqueólogo acadêmico (35 anos)
2. Jackson Elias — investigador destemido (41 anos)
3. Trinidad Rizo — estudante empolgada (19 anos)
4. Petronila Cupitina — hoteleira pragmática (71 anos)
5. Nayra — curandeira e sábia (76 anos)
6. Julio Céspedes — pai protetor (38 anos)
7. Domingo Céspedes — filho gravemente ferido (15 anos)

### Pasta: Adversários e Monstros (7 criaturas/NPCs)
8. Augustus Larkin (humano) — hospedeiro de Nyarlathotep (32 anos)
9. Augustus Larkin Possuído por Nyarlathotep — arauto das trevas
10. Luis de Mendoza — conquistador morto-vivo (kharisiri)
11. Kharisiri — sanguessuga imortal (perfil genérico com variações)
12. Múmia Animada — suposto monte de trapos
13. Larva de Kharisiri — semente de um deus
14. Pai dos Vermes — avatar aprisionado de Nyarlathotep

## Estrutura do módulo

```
personagens-mascaras/
├── module.json              # Manifesto do módulo
├── README.md                # Este arquivo
├── lang/
│   └── pt-BR.json           # Traduções (pt-BR)
├── src/
│   └── packs/
│       └── peru-personagens.yaml   # Fonte YAML do compêndio (editável)
├── packs/
│   └── peru-personagens/    # Pack LevelDB gerado (vazio até empacotar)
└── generate.py              # Script gerador (Python)
```

## Como empacotar (foundryvtt-cli)

Os compêndios em Foundry VTT v11+ usam formato **LevelDB**. Os arquivos `src/packs/*.yaml` são fontes legíveis que devem ser convertidas:

```bash
# Instalar a CLI (uma vez)
npm install -g @foundryvtt/foundryvtt-cli

# Configurar o caminho do Foundry (uma vez)
fvtt configure set dataPath "/caminho/para/FoundryVTT/Data"

# Converter YAML -> LevelDB (pack)
fvtt package pack --in src/packs/peru-personagens.yaml --out packs/peru-personagens --id personagens-mascaras --type Actor

# Para descompactar de volta (LevelDB -> YAML)
fvtt package unpack --in packs/peru-personagens --out src/packs/peru-personagens.yaml --id personagens-mascaras --type Actor
```

## Instalação

1. Empacote o YAML para LevelDB (comando acima)
2. Copie a pasta `personagens-mascaras` para `FoundryVTT/Data/modules/`
3. No Foundry VTT, ative o módulo nas configurações do mundo (sistema CoC7)
4. O compêndio **"Peru - Personagens"** aparecerá na aba de Compêndios

## Requisitos

- Foundry VTT v11+ (testado até v12)
- Sistema **Call of Cthulhu 7th Edition** (`CoC7`) instalado

## Próximos passos

- [ ] Capítulo: Inglaterra (Londres)
- [ ] Capítulo: Egito (Cairo)
- [ ] Capítulo: Quênia (Nairobi)
- [ ] Capítulo: Austrália (Melbourne)
- [ ] Compêndio separado de **Magias/Feitiços**
- [ ] Compêndio de **Livros do Mythos**

## Notas

- Domingo Céspedes já está com PVs reduzidos (3/11) e movimento 0/9 devido aos ferimentos iniciais do cenário.
- Criaturas incluem perda de Sanidade (`sanLoss`) configurada nos campos apropriados.
- Armas referenciam suas perícias correspondentes via `_id` interno.
- Talentos Pulp estão incluídos como itens do tipo `talent`.
